# Trading Dashboard Verbesserungen

## Aufgaben

- [x] Projekt auf Port 8050 schließen
- [ ] Symbol aus Strategie-Konfiguration entfernen und alle Assets als Dropdown mit Suchfeld bereitstellen
- [ ] NQ Zeitdaten hinzufügen
- [ ] Letzten Chart & Zeitdaten für den Nutzer speichern (als Default-Asset bei erneutem Laden)
- [ ] Verfügbare Werkzeuge an den linken Rand verschieben (wie in TradingView)
- [ ] Auswählbare Zeiteinheiten direkt über den Chart platzieren (wie in TradingView)
- [ ] Projekt ausführen und auf Fehler prüfen
- [ ] ZIP-Datei des Projekts erstellen
